<template>
  <h2>
    Welcome to Yaniv Assaf's lab!
  </h2>
</template>

<script>
export default {}
</script>
