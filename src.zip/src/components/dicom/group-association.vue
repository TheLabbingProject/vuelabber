<template>
  <v-container fluid>
    <v-layout wrap>
      <v-flex pr-5>
        <v-combobox
          v-model="selectedStudyTitle"
          append-outer-icon="add_circle"
          label="Select study"
          :items="studies.map(item => item.title)"
          @click:append-outer.stop="createStudyDialog = true"
        />
        <v-layout row justify-center>
          <v-dialog v-model="createStudyDialog" width="600px" lazy persistent>
            <create-study @close-study-dialog="createStudyDialog = false" />
          </v-dialog>
        </v-layout>
      </v-flex>
      <v-flex pr-5>
        <v-combobox
          v-model="selectedGroupTitle"
          append-outer-icon="add_circle"
          label="Select group"
          :disabled="!selectedStudy"
          :items="studyGroups.map(group => group.title)"
          @click:append-outer.stop="createGroupDialog = true"
        />
        <v-layout row justify-center>
          <v-dialog v-model="createGroupDialog" width="600px" lazy persistent>
            <create-group-dialog
              @close-group-dialog="closeGroupDialog"
              @select-study="selectedStudyTitle = arguments[0]"
              :selectedStudy="selectedStudy"
            />
          </v-dialog>
        </v-layout>
      </v-flex>
      <v-btn @click="addSelection" :disabled="!selectedGroupTitle">
        Select Group
      </v-btn>
    </v-layout>
    <v-layout wrap>
      <v-flex fill-height class="text-xs-left">
        Selected Groups:
        <v-chip v-for="selection in selections" :key="selection.id">
          {{ `${selection.study.title} | ${selection.title}` }}
        </v-chip>
      </v-flex>
      <v-btn
        @click="associateSeriesToStudyGroups"
        color="success"
        :disabled="selections.length == 0"
      >
        Associate
      </v-btn>
    </v-layout>
  </v-container>
</template>

<script>
import CreateGroupDialog from '@/components/research/create-group-dialog.vue'
import CreateStudy from '@/components/research/create-study.vue'
import { mapGetters, mapState } from 'vuex'

export default {
  name: 'GroupAssociation',
  props: {
    selectedSeries: Array
  },
  components: { CreateGroupDialog, CreateStudy },
  created() {
    this.$store.dispatch('research/fetchStudies')
    this.$store.dispatch('research/fetchGroups')
  },
  data: () => ({
    selectedStudyTitle: '',
    selectedStudy: null,
    selectedGroupTitle: '',
    selectedGroup: null,
    selections: [],
    studyGroups: [],
    createStudyDialog: false,
    createGroupDialog: false
  }),
  computed: {
    ...mapState('research', ['studies', 'groups']),
    ...mapGetters('research', [
      'getStudyByTitle',
      'getStudyGroups',
      'getStudyGroupByTitle'
    ])
  },
  watch: {
    selectedStudyTitle: function(title) {
      if (title) {
        this.selectedStudy = this.getStudyByTitle(title)
      } else {
        this.selectedStudy = null
      }
    },
    selectedStudy: function(study) {
      if (study) {
        this.studyGroups = this.getStudyGroups(study)
        this.selectedGroupTitle = ''
      } else {
        this.studyGroups = []
        this.selectedGroup = null
      }
    },
    selectedGroupTitle: function(groupTitle) {
      if (groupTitle) {
        console.log('called')
        this.selectedGroup = this.getStudyGroupByTitle({
          study: this.selectedStudy,
          groupTitle
        })
      } else {
        this.selectedGroup = null
      }
    }
  },
  methods: {
    getSelectionString: function() {
      return `${this.selectedStudy.title} | ${this.selectedGroup.title}`
    },
    addSelection: function() {
      this.selections.push(this.selectedGroup)
    },
    associateSeriesToStudyGroups() {
      this.selectedSeries.forEach(series => console.log(series.id))
    },
    closeGroupDialog: function() {
      this.createGroupDialog = false
      this.studyGroups = this.getStudyGroups(this.selectedStudy)
    }
  }
}
</script>

<style lang="scss" scoped></style>
